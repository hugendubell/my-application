package com.example.Common;

import com.example.Model.User;

public class Common {
    public  static User currentUser;
}
